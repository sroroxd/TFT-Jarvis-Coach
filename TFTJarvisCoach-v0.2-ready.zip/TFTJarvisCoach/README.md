# TFT Jarvis Coach — Android V0.2

Diese Version ist für Nutzung direkt auf einem Android-Handy gedacht. Nach der Installation liest sie den Bildschirm ausschließlich nach Androids ausdrücklicher Bildschirmfreigabe, sendet einen verkleinerten TFT-Screenshot an die OpenAI Responses API und zeigt einen sehr kurzen Coaching-Call im Overlay an. Der Call wird zusätzlich auf Deutsch vorgelesen.

## Im Spiel

- **START COACHING**: Overlay- und Bildschirmfreigabe einrichten.
- **MERKEN**: aktuellen sichtbaren TFT-Zustand sofort analysieren.
- **AUTO** im Overlay: Analyse im eingestellten Intervall.
- **RESET**: Match-Kurzgedächtnis löschen, z. B. vor einem neuen Match.
- Das Modell hält intern einen sehr kurzen Board-Kurzstatus aus dem vorherigen Call, damit aufeinanderfolgende MERKEN-Aufrufe nicht völlig isoliert sind.
- Die sichtbare Empfehlung ist technisch auf maximal fünf Wörter begrenzt.
- Top-1 ist das primäre Optimierungsziel.

## Datenschutz und API-Key

Der API-Key wird, sofern Android Keystore verfügbar ist, verschlüsselt auf dem Gerät gespeichert. Screenshots werden nur während aktiver Bildschirmfreigabe erfasst. Für jede Analyse wird der aktuelle verkleinerte Screenshot an die OpenAI API übertragen. API-Abrechnung ist getrennt von einem ChatGPT-Abo.

## Ohne PC eine APK bauen

Das Projekt enthält `.github/workflows/build-apk.yml`.

1. Auf GitHub ein leeres Repository anlegen.
2. Den **Inhalt** dieses Projektordners hochladen, sodass `app/`, `gradle/`, `gradlew` und `.github/` direkt im Repository liegen.
3. GitHub → **Actions** → **Build Android APK** öffnen.
4. `Run workflow` drücken (bei einem Upload auf `main` startet es normalerweise schon automatisch).
5. Nach erfolgreichem Lauf unter **Artifacts** `TFT-Jarvis-Coach-APK` herunterladen.
6. ZIP des Artifacts öffnen und `app-debug.apk` auf dem Samsung installieren. Android kann dafür einmalig „Unbekannte Apps installieren“ für den verwendeten Browser/Dateimanager verlangen.

## Technischer Stand

- minSdk 29, target/compileSdk 35
- Java 17
- Android Gradle Plugin 8.7.3, Gradle 8.9
- MediaProjection-Foreground-Service
- Overlay über `SYSTEM_ALERT_WINDOW`
- Responses API mit Bild-Input
- Bild wird auf maximal 1920 px Kantenlänge reduziert
- keine automatischen TFT-Klicks oder Eingaben

## Was absichtlich noch nicht enthalten ist

Ein dauerhaft im Hintergrund lauschendes Sprach-Keyword wie „Merken“ ist in V0.2 nicht aktiviert. Android beschränkt permanentes Mikrofon-Listening stark; ein unzuverlässiger Always-on-Hack wäre für Live-Coaching schlechter als der sofort erreichbare MERKEN-Button im Overlay. Das kann später als eigener, sauberer Sprachmodus ergänzt werden.
